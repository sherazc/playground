import * as React from "react"
import Svg, { Path } from "react-native-svg"
interface Props {
    height?: number;
    width?: number;
    fill?: string;
}
export const VerticalLine: React.FC<Props> = ({ width = 5, height = 86, fill = "#000" }) => {
    return (
        <Svg width={width} height={height} viewBox="0 0 5 86">
            <Path fill={fill} d="M 2.49855,85.93013 C 1.70557,75.06224 1.11004,59.07057 0.11875001,52.76194 c 0.0771,-3.61896 4.76249999,-3.74077 4.76249999,0 C 3.61416,58.95736 2.9607,75.19261 2.49855,85.93013 Z M 4.447545,43 A 1.9475399,2.0875363 0 0 1 2.499995,45.08753 1.9475399,2.0875363 0 0 1 0.55245501,43 1.9475399,2.0875363 0 0 1 2.499995,40.91246 1.9475399,2.0875363 0 0 1 4.447545,43 Z M 2.49855,0.06987008 C 1.70557,10.93775 1.11004,26.92942 0.11875002,33.23805 c 0.0771,3.61896 4.76249998,3.74077 4.76249998,0 C 3.61416,27.04263 2.9607,10.80738 2.49855,0.06987008 Z" />
        </Svg>
    )
}
export default VerticalLine;