#!/bin/bash
npx react-native run-ios
